/* Finix web UI. Mirrors the rules of the Java domain classes in src/ and keeps data in localStorage. */
(() => {
  'use strict';

  /* ---------- helpers ---------- */
  const KEY = 'finix.web.v1';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const el = (tag, attrs = {}, ...kids) => {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === false || v == null) continue;
      if (k === 'class') n.className = v;
      else n.setAttribute(k, v === true ? '' : v);
    }
    kids.flat().forEach(c => n.append(c instanceof Node ? c : document.createTextNode(c)));
    return n;
  };

  const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const round2 = n => Math.round((n + Number.EPSILON) * 100) / 100;
  const money = n => inr.format(round2(n));
  const dateFmt = new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  const timeFmt = new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  const fmtDate = iso => dateFmt.format(new Date(iso));

  /* ---------- domain rules (same as Account_Classes/*.java) ---------- */
  const SAVINGS_MIN = 1000;
  const OVERDRAFT = 10000;
  const FD_MIN = 5000;
  const TYPES = {
    SAVINGS: { label: 'Savings', rate: 0.04, rule: 'Keeps at least ₹1,000' },
    CURRENT: { label: 'Current', rate: 0, rule: 'Overdraft up to ₹10,000' },
    FIXED_DEPOSIT: { label: 'Fixed deposit', rate: 0.07, rule: 'Withdrawals open at maturity' }
  };
  const TXN = {
    DEPOSIT: { label: 'Deposit', credit: true },
    WITHDRAWAL: { label: 'Withdrawal', credit: false },
    TRANSFER_IN: { label: 'Transfer in', credit: true },
    TRANSFER_OUT: { label: 'Transfer out', credit: false },
    INTEREST_CREDIT: { label: 'Interest credit', credit: true }
  };

  const label = a => `${TYPES[a.type].label} ${a.no}`;
  const isMatured = a => a.type === 'FIXED_DEPOSIT' && new Date() >= new Date(a.maturesOn);

  function interestOf(a) {
    if (a.type === 'SAVINGS') return round2(a.balance * TYPES.SAVINGS.rate);
    if (a.type === 'FIXED_DEPOSIT') return round2(a.balance * TYPES.FIXED_DEPOSIT.rate * a.years);
    return 0;
  }

  /** Returns a message when the withdrawal is not allowed, otherwise null. */
  function withdrawError(a, amt) {
    if (a.type === 'FIXED_DEPOSIT') {
      if (!isMatured(a)) return `This fixed deposit matures on ${fmtDate(a.maturesOn)}. Withdrawals open then.`;
      if (amt > a.balance) return `The deposit holds ${money(a.balance)}. Enter that amount or less.`;
    }
    if (a.type === 'SAVINGS' && a.balance - amt < SAVINGS_MIN) {
      const max = Math.max(0, round2(a.balance - SAVINGS_MIN));
      return `Savings must keep ${money(SAVINGS_MIN)}. You can withdraw up to ${money(max)}.`;
    }
    if (a.type === 'CURRENT' && a.balance - amt <= -OVERDRAFT) {
      const max = round2(a.balance + OVERDRAFT - 0.01);
      return `That passes the ${money(OVERDRAFT)} overdraft limit. You can withdraw up to ${money(max)}.`;
    }
    return null;
  }

  /* ---------- state ---------- */
  function seed() {
    const now = new Date();
    const plusYears = (d, y) => { const x = new Date(d); x.setFullYear(x.getFullYear() + y); return x.toISOString(); };
    const accounts = [
      { no: 1001, type: 'SAVINGS', holder: { name: 'Prakash', city: 'Hyderabad', phone: '6302714896' }, balance: 10000, openedOn: now.toISOString() },
      { no: 1002, type: 'CURRENT', holder: { name: 'Rahul', city: 'Bangalore', phone: '' }, balance: 20000, openedOn: now.toISOString() },
      { no: 1003, type: 'FIXED_DEPOSIT', holder: { name: 'Kiran', city: 'Chennai', phone: '' }, balance: 50000, openedOn: now.toISOString(), years: 12, maturesOn: plusYears(now, 12) }
    ];
    const txns = accounts.map((a, i) => ({ id: 10001 + i, acc: a.no, type: 'DEPOSIT', amount: a.balance, status: 'SUCCESS', at: now.toISOString(), note: 'Opening deposit' }));
    return { accounts, txns, nextTxn: 10001 + accounts.length, selected: 1001 };
  }
  function load() {
    try {
      const s = JSON.parse(localStorage.getItem(KEY));
      return s && Array.isArray(s.accounts) && Array.isArray(s.txns) ? s : null;
    } catch { return null; }
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* storage unavailable */ } }

  let state = load() || seed();
  const ui = { kind: 'deposit', filter: 'all', scope: 'all', freshTxn: null };

  const acc = no => state.accounts.find(a => a.no === Number(no));
  const current = () => acc(state.selected) || state.accounts[0];
  const selIndex = () => Math.max(0, state.accounts.findIndex(a => a.no === state.selected));

  function addTxn(no, type, amount, note) {
    const t = { id: state.nextTxn++, acc: no, type, amount: round2(amount), status: 'SUCCESS', at: new Date().toISOString(), note: note || '' };
    state.txns.push(t);
    ui.freshTxn = t.id;
    return t;
  }

  /* ---------- small UI utilities ---------- */
  function toast(msg) {
    const t = el('div', { class: 'toast' }, el('span', {}, msg));
    $('#toasts').append(t);
    setTimeout(() => { t.classList.add('leaving'); setTimeout(() => t.remove(), 320); }, 4200);
  }

  function tween(node, from, to) {
    if (reduce || from === to) { node.textContent = money(to); return; }
    node.textContent = money(from);
    const t0 = performance.now(), dur = 700;
    const step = t => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      node.textContent = money(from + (to - from) * e);
      if (p < 1) requestAnimationFrame(step); else node.textContent = money(to);
    };
    requestAnimationFrame(step);
  }

  function askConfirm({ title, body, confirmLabel }) {
    const dlg = $('#confirmDlg');
    $('#confirmTitle').textContent = title;
    $('#confirmBody').textContent = body;
    $('#confirmOk').textContent = confirmLabel;
    dlg.returnValue = '';
    dlg.showModal();
    return new Promise(res => dlg.addEventListener('close', () => res(dlg.returnValue === 'ok'), { once: true }));
  }

  const icon = dir => {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('aria-hidden', 'true');
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d', dir === 'in' ? 'M12 5v14m0 0l-6-6m6 6l6-6' : 'M12 19V5m0 0l-6 6m6-6l6 6');
    svg.append(p);
    return svg;
  };

  /* ---------- total ---------- */
  let lastTotal = null;
  function renderTotal() {
    const total = round2(state.accounts.reduce((s, a) => s + a.balance, 0));
    const n = state.accounts.length;
    const line = $('#totalLine');
    line.replaceChildren('Total balance ');
    const strong = el('strong', {});
    line.append(strong, ` across ${n} ${n === 1 ? 'account' : 'accounts'}`);
    if (lastTotal === null) strong.textContent = money(total); else tween(strong, lastTotal, total);
    lastTotal = total;
  }

  /* ---------- deck ---------- */
  function renderDeck() {
    const deck = $('#deck');
    deck.replaceChildren();
    state.accounts.forEach(a => {
      const matures = a.type === 'FIXED_DEPOSIT';
      const front = el('div', { class: 'face front' },
        el('div', { class: 'card-top' }, el('span', { class: 'card-brand' }, 'Finix'), el('span', { class: 'card-type' }, TYPES[a.type].label)),
        el('div', { class: 'chip', 'aria-hidden': 'true' }),
        el('div', { class: 'card-no' }, String(a.no).replace(/(\d{4})(?=\d)/g, '$1 ')),
        el('div', { class: 'card-bottom' },
          el('span', { class: 'card-holder' }, a.holder.name),
          el('span', { class: 'card-meta' }, matures ? `Matures ${fmtDate(a.maturesOn)}` : `Since ${fmtDate(a.openedOn)}`)));
      const rows = [
        ['Holder', a.holder.name], ['City', a.holder.city || 'Not added'], ['Phone', a.holder.phone || 'Not added'],
        ['Interest', a.type === 'CURRENT' ? 'None' : `${Math.round(TYPES[a.type].rate * 10000) / 100}% a year`],
        ['Opened', fmtDate(a.openedOn)]
      ];
      if (matures) rows.push(['Matures', fmtDate(a.maturesOn)]);
      const back = el('div', { class: 'face back' }, el('div', { class: 'strip' }),
        el('dl', {}, rows.map(([k, v]) => [el('dt', {}, k), el('dd', {}, v)]).flat()));
      const card = el('div', { class: `card t-${a.type}`, role: 'button', tabindex: '0', 'data-no': a.no }, el('div', { class: 'flip' }, front, back));
      deck.append(card);
    });
    layoutDeck();
  }

  function layoutDeck() {
    const n = state.accounts.length, sel = selIndex();
    $$('.card').forEach((c, i) => {
      const a = state.accounts[i];
      const o = (i - sel + n) % n;
      c.style.setProperty('--o', o);
      c.classList.toggle('is-front', o === 0);
      c.classList.toggle('is-hidden', o > 3);
      c.tabIndex = o > 3 ? -1 : 0;
      c.setAttribute('aria-label', `${label(a)} for ${a.holder.name}. ${o === 0 ? 'Selected. Press Enter to flip the card.' : 'Press Enter to select.'}`);
      if (o !== 0) $('.flip', c).classList.remove('is-flipped');
    });
  }

  function liftFront() {
    const c = $('.card.is-front');
    if (!c || reduce) return;
    c.classList.remove('lift'); void c.offsetWidth; c.classList.add('lift');
    setTimeout(() => c.classList.remove('lift'), 750);
  }

  function select(no) {
    if (state.selected === no) return;
    state.selected = no;
    save();
    layoutDeck();
    renderFocus();
    renderLedger();
    syncFrom();
  }
  function step(dir) {
    const n = state.accounts.length;
    if (n < 2) return;
    select(state.accounts[(selIndex() + dir + n) % n].no);
  }

  /* ---------- focus panel ---------- */
  let lastBal = { no: null, value: 0 };
  function renderFocus() {
    const box = $('#focus');
    const a = state.accounts.length ? current() : null;
    box.replaceChildren();
    if (!a) {
      box.classList.add('empty-focus');
      box.append(el('h2', {}, 'No accounts yet'), el('p', { class: 'holder' }, 'Open your first account to start moving money.'),
        el('div', { class: 'actions' }, el('button', { type: 'button', class: 'btn btn-gold', id: 'emptyOpen' }, 'Open account')));
      $('#emptyOpen').addEventListener('click', openDialog);
      lastBal = { no: null, value: 0 };
      return;
    }
    box.classList.remove('empty-focus');

    const balEl = el('div', { class: `bal${a.balance < 0 ? ' neg' : ''}` });
    const thirdTerm = a.type === 'FIXED_DEPOSIT' ? 'Matures' : 'Opened';
    const thirdVal = a.type === 'FIXED_DEPOSIT' ? fmtDate(a.maturesOn) : fmtDate(a.openedOn);
    const interestTerm = a.type === 'FIXED_DEPOSIT' ? `Interest over ${a.years} ${a.years === 1 ? 'year' : 'years'}` : a.type === 'SAVINGS' ? 'Yearly interest' : 'Interest';

    box.append(
      a.type === 'FIXED_DEPOSIT'
        ? el('span', { class: `pill ${isMatured(a) ? 'ok' : 'lock'}` }, isMatured(a) ? 'Matured, open for withdrawal' : 'Locked until maturity')
        : el('span', { class: 'pill ok' }, 'Active'),
      el('div', {}, el('h2', {}, `${TYPES[a.type].label} ${a.no}`), el('p', { class: 'holder' }, `${a.holder.name}, ${a.holder.city || 'city not added'}`)),
      el('div', {}, el('p', { class: 'bal-label' }, 'Balance'), balEl),
      el('dl', { class: 'facts' },
        el('div', {}, el('dt', {}, interestTerm), el('dd', {}, a.type === 'CURRENT' ? 'None' : money(interestOf(a)))),
        el('div', {}, el('dt', {}, 'Rule'), el('dd', {}, TYPES[a.type].rule)),
        el('div', {}, el('dt', {}, thirdTerm), el('dd', {}, thirdVal))),
      el('div', { class: 'actions' },
        el('button', { type: 'button', class: 'btn btn-gold', 'data-go': 'deposit' }, 'Deposit'),
        el('button', { type: 'button', class: 'btn btn-ghost', 'data-go': 'withdraw' }, 'Withdraw'),
        el('button', { type: 'button', class: 'btn btn-ghost', 'data-go': 'transfer' }, 'Transfer'),
        el('button', { type: 'button', class: 'btn-text', id: 'closeAcct' }, 'Close account')));

    if (lastBal.no === a.no) tween(balEl, lastBal.value, a.balance); else balEl.textContent = money(a.balance);
    lastBal = { no: a.no, value: a.balance };

    $$('[data-go]', box).forEach(b => b.addEventListener('click', () => {
      setKind(b.dataset.go);
      $('#move').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
      setTimeout(() => $('#amountIn').focus({ preventScroll: true }), reduce ? 0 : 350);
    }));
    $('#closeAcct').addEventListener('click', closeAccount);
  }

  async function closeAccount() {
    const a = current();
    const ok = await askConfirm({
      title: `Close ${label(a)}?`,
      body: `The account and its ${money(a.balance)} balance will be removed. Move the money to another account first if you need it. Past activity stays in the list.`,
      confirmLabel: 'Close account'
    });
    if (!ok) return;
    state.accounts = state.accounts.filter(x => x.no !== a.no);
    state.selected = state.accounts.length ? state.accounts[0].no : null;
    save();
    lastBal = { no: null, value: 0 };
    renderAll();
    toast(`Account closed: ${label(a)}.`);
  }

  /* ---------- move money ---------- */
  const fromSel = $('#fromSel'), toSel = $('#toSel'), amountIn = $('#amountIn'), noteIn = $('#noteIn');
  const submitBtn = $('#submitBtn');

  function fillSelects() {
    const make = () => state.accounts.map(a => el('option', { value: a.no }, `${a.holder.name}, ${label(a)}`));
    fromSel.replaceChildren(...make());
    toSel.replaceChildren(...make());
    syncFrom();
  }
  function fixTo() {
    if (toSel.value === fromSel.value && state.accounts.length > 1) {
      const other = state.accounts.find(a => String(a.no) !== fromSel.value);
      if (other) toSel.value = String(other.no);
    }
  }
  function syncFrom() {
    if (!state.accounts.length) { evaluate(); return; }
    fromSel.value = String(state.selected);
    fixTo();
    evaluate();
  }

  function setKind(kind) {
    ui.kind = kind;
    $$('#kindSeg button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.kind === kind)));
    $('#toField').hidden = kind !== 'transfer';
    $('#fromLabel').textContent = { deposit: 'Deposit to', withdraw: 'Withdraw from', transfer: 'From account' }[kind];
    submitBtn.textContent = { deposit: 'Deposit', withdraw: 'Withdraw', transfer: 'Transfer' }[kind];
    fixTo();
    evaluate();
  }

  const parseAmount = raw => {
    const s = String(raw).replace(/[,\s₹]/g, '');
    if (s === '') return NaN;
    const n = Number(s);
    return Number.isFinite(n) ? round2(n) : NaN;
  };

  function evaluate() {
    const err = $('#moveError'), prev = $('#preview');
    err.textContent = ''; prev.replaceChildren();
    submitBtn.disabled = true;
    const from = acc(fromSel.value), to = acc(toSel.value), amt = parseAmount(amountIn.value);
    if (!from) { err.textContent = 'Open an account to start moving money.'; return null; }
    if (ui.kind === 'transfer' && state.accounts.length < 2) { err.textContent = 'Open a second account to make a transfer.'; return null; }
    if (amountIn.value.trim() === '') return null;
    if (Number.isNaN(amt)) { err.textContent = 'Enter the amount using digits, for example 2500.'; return null; }
    if (amt <= 0) { err.textContent = 'Enter an amount greater than zero.'; return null; }
    if (ui.kind === 'transfer' && (!to || from.no === to.no)) { err.textContent = 'Pick two different accounts.'; return null; }
    if (ui.kind !== 'deposit') {
      const msg = withdrawError(from, amt);
      if (msg) { err.textContent = msg; return null; }
    }
    const fromAfter = ui.kind === 'deposit' ? from.balance + amt : from.balance - amt;
    prev.append(el('span', {}, `${label(from)} will hold `, el('strong', {}, money(fromAfter))));
    if (ui.kind === 'transfer') prev.append(el('span', {}, `${label(to)} will hold `, el('strong', {}, money(to.balance + amt))));
    submitBtn.disabled = false;
    return { from, to, amt };
  }

  $('#moveForm').addEventListener('submit', e => {
    e.preventDefault();
    const r = evaluate();
    if (!r) return;
    const { from, to, amt } = r, note = noteIn.value.trim();
    if (ui.kind === 'deposit') {
      from.balance = round2(from.balance + amt);
      addTxn(from.no, 'DEPOSIT', amt, note);
      toast(`Deposit complete: ${money(amt)} added to ${label(from)}.`);
    } else if (ui.kind === 'withdraw') {
      from.balance = round2(from.balance - amt);
      addTxn(from.no, 'WITHDRAWAL', amt, note);
      toast(`Withdrawal complete: ${money(amt)} taken from ${label(from)}.`);
    } else {
      from.balance = round2(from.balance - amt);
      to.balance = round2(to.balance + amt);
      addTxn(from.no, 'TRANSFER_OUT', amt, note ? `To ${to.no}: ${note}` : `To ${label(to)}`);
      addTxn(to.no, 'TRANSFER_IN', amt, note ? `From ${from.no}: ${note}` : `From ${label(from)}`);
      toast(`Transfer complete: ${money(amt)} sent from ${label(from)} to ${label(to)}.`);
    }
    save();
    amountIn.value = ''; noteIn.value = '';
    renderTotal(); renderFocus(); renderLedger(); evaluate(); liftFront();
    amountIn.focus({ preventScroll: true });
  });

  amountIn.addEventListener('input', evaluate);
  fromSel.addEventListener('change', () => { const no = Number(fromSel.value); if (no !== state.selected) select(no); else { fixTo(); evaluate(); } });
  toSel.addEventListener('change', evaluate);
  $('#kindSeg').addEventListener('click', e => { const b = e.target.closest('button[data-kind]'); if (b) setKind(b.dataset.kind); });
  $('#quickAmts').addEventListener('click', e => { const b = e.target.closest('button[data-amt]'); if (b) { amountIn.value = b.dataset.amt; evaluate(); amountIn.focus(); } });

  /* ---------- ledger ---------- */
  function renderLedger() {
    const list = $('#ledgerList');
    list.replaceChildren();
    const groups = { deposits: ['DEPOSIT', 'INTEREST_CREDIT'], withdrawals: ['WITHDRAWAL'], transfers: ['TRANSFER_IN', 'TRANSFER_OUT'] };
    const rows = state.txns.slice().sort((a, b) => b.id - a.id).filter(t =>
      (ui.scope === 'all' || t.acc === state.selected) && (ui.filter === 'all' || groups[ui.filter].includes(t.type)));
    if (!rows.length) {
      list.append(el('li', { class: 'empty' }, el('strong', {}, 'No transactions here yet'),
        ui.scope === 'this' || ui.filter !== 'all' ? 'Try another filter, or make a deposit to see it listed.' : 'Make a deposit and it will appear in this list.'));
      return;
    }
    rows.forEach(t => {
      const credit = TXN[t.type].credit, a = acc(t.acc);
      const row = el('li', { class: `row${t.id === ui.freshTxn ? ' fresh' : ''}` },
        el('span', { class: `ico ${credit ? 'in' : 'out'}` }, icon(credit ? 'in' : 'out')),
        el('div', {}, el('div', { class: 't' }, TXN[t.type].label),
          el('div', { class: 's' }, [a ? label(a) : `Closed account ${t.acc}`, t.note].filter(Boolean).join(', '))),
        el('div', { class: `amt ${credit ? 'in' : 'out'}` }, `${credit ? '+' : '-'}${money(t.amount)}`,
          el('span', { class: 'when' }, timeFmt.format(new Date(t.at)))));
      list.append(row);
    });
    ui.freshTxn = null;
  }
  $('#filterChips').addEventListener('click', e => {
    const b = e.target.closest('button[data-filter]'); if (!b) return;
    ui.filter = b.dataset.filter;
    $$('#filterChips button').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    renderLedger();
  });
  $('#scopeSeg').addEventListener('click', e => {
    const b = e.target.closest('button[data-scope]'); if (!b) return;
    ui.scope = b.dataset.scope;
    $$('#scopeSeg button').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    renderLedger();
  });

  /* ---------- open account dialog ---------- */
  const openDlg = $('#openDlg'), openForm = $('#openForm');
  const nextNo = () => state.accounts.reduce((m, a) => Math.max(m, a.no), 1000) + 1;

  function openDialog() {
    openForm.reset();
    $('#openError').textContent = '';
    $('#nYears').value = 1;
    syncType();
    openDlg.showModal();
    $('#nName').focus();
  }
  function selectedType() { return openForm.elements.atype.value; }
  function syncType() {
    const t = selectedType();
    $('#nYearsField').hidden = t !== 'FIXED_DEPOSIT';
    $('#nAmount').placeholder = { SAVINGS: 'At least 1,000', CURRENT: '0 or more', FIXED_DEPOSIT: 'At least 5,000' }[t];
    $('#newNo').textContent = `The new account number will be ${nextNo()}.`;
  }
  openForm.addEventListener('change', syncType);
  $('#openBtn').addEventListener('click', openDialog);
  $('[data-close]', openDlg).addEventListener('click', () => openDlg.close());
  [openDlg, $('#confirmDlg')].forEach(d => d.addEventListener('click', e => { if (e.target === d) d.close(); }));

  openForm.addEventListener('submit', e => {
    e.preventDefault();
    const err = $('#openError');
    const type = selectedType();
    const name = $('#nName').value.trim(), city = $('#nCity').value.trim(), phone = $('#nPhone').value.trim();
    const amt = parseAmount($('#nAmount').value), years = parseInt($('#nYears').value, 10);
    const fail = m => { err.textContent = m; };
    if (!name) return fail('Enter the holder name.');
    if (!city) return fail('Enter the city.');
    if (phone && !/^\d{10}$/.test(phone)) return fail('Phone numbers need 10 digits, or leave the field empty.');
    if (Number.isNaN(amt)) return fail('Enter the opening amount using digits.');
    if (type === 'SAVINGS' && amt < SAVINGS_MIN) return fail(`Savings accounts open with at least ${money(SAVINGS_MIN)}.`);
    if (type === 'CURRENT' && amt < 0) return fail('The opening amount cannot be negative.');
    if (type === 'FIXED_DEPOSIT') {
      if (amt < FD_MIN) return fail(`Fixed deposits open with at least ${money(FD_MIN)}.`);
      if (!Number.isInteger(years) || years < 1 || years > 30) return fail('Choose a term between 1 and 30 years.');
    }
    const now = new Date();
    const a = { no: nextNo(), type, holder: { name, city, phone }, balance: round2(amt), openedOn: now.toISOString() };
    if (type === 'FIXED_DEPOSIT') {
      const m = new Date(now); m.setFullYear(m.getFullYear() + years);
      a.years = years; a.maturesOn = m.toISOString();
    }
    state.accounts.push(a);
    if (amt > 0) addTxn(a.no, 'DEPOSIT', amt, 'Opening deposit');
    state.selected = a.no;
    save();
    openDlg.close();
    lastBal = { no: null, value: 0 };
    renderAll();
    toast(`Account opened: ${label(a)} for ${name}.`);
  });

  /* ---------- rail, reset, keyboard, pointer tilt ---------- */
  $$('.rail-nav a').forEach(a => a.addEventListener('click', () => {
    $$('.rail-nav a').forEach(x => { x.classList.toggle('is-current', x === a); if (x === a) x.setAttribute('aria-current', 'page'); else x.removeAttribute('aria-current'); });
  }));

  $('#resetBtn').addEventListener('click', async () => {
    const ok = await askConfirm({ title: 'Reset demo data?', body: 'All accounts and activity return to the starting set of three accounts. Your changes will be removed.', confirmLabel: 'Reset data' });
    if (!ok) return;
    state = seed(); ui.freshTxn = null; lastBal = { no: null, value: 0 }; lastTotal = null;
    save(); renderAll();
    toast('Demo data reset.');
  });

  $('#prevBtn').addEventListener('click', () => step(-1));
  $('#nextBtn').addEventListener('click', () => step(1));

  const deck = $('#deck');
  deck.addEventListener('click', e => {
    const c = e.target.closest('.card'); if (!c || c.classList.contains('is-hidden')) return;
    const no = Number(c.dataset.no);
    if (no !== state.selected) select(no); else $('.flip', c).classList.toggle('is-flipped');
  });
  deck.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') { e.preventDefault(); step(1); $('.card.is-front')?.focus(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); step(-1); $('.card.is-front')?.focus(); }
    else if (e.key === 'Enter' || e.key === ' ') {
      const c = e.target.closest('.card'); if (!c) return;
      e.preventDefault(); c.click();
    }
  });

  const stage = $('#stage');
  const setTilt = (ry, rx, px, py) => {
    stage.style.setProperty('--ry', ry); stage.style.setProperty('--rx', rx);
    stage.style.setProperty('--px', px); stage.style.setProperty('--py', py);
  };
  if (!reduce) {
    stage.addEventListener('pointermove', e => {
      const r = stage.getBoundingClientRect();
      const px = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      const py = Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
      setTilt((-14 + (px - 0.5) * 22).toFixed(2), (6 - (py - 0.5) * 14).toFixed(2), (px * 100).toFixed(1) + '%', (py * 100).toFixed(1) + '%');
    });
    stage.addEventListener('pointerleave', () => setTilt(-14, 6, '30%', '20%'));
  }
  setTimeout(() => stage.classList.remove('intro'), 1500);

  /* ---------- boot ---------- */
  function renderAll() {
    renderTotal();
    renderDeck();
    renderFocus();
    fillSelects();
    renderLedger();
  }
  if (state.accounts.length && !acc(state.selected)) state.selected = state.accounts[0].no;
  renderAll();
  setKind('deposit');
})();
